import os, getpass
from qiskit_ibm_runtime import QiskitRuntimeService

def main():
    token = os.getenv("QISKIT_IBM_TOKEN") or getpass.getpass("Enter IBM Quantum API token: ")
    if not token:
        raise SystemExit("No token provided.")
    # Save account; choose the new channel names (ibm_quantum_platform or ibm_cloud)
    QiskitRuntimeService.save_account(
        channel="ibm_quantum_platform",
        token=token,
        set_as_default=True,
        overwrite=True,
    )
    print("IBM Quantum credentials saved for Qiskit Runtime.")

if __name__ == "__main__":
    main()
