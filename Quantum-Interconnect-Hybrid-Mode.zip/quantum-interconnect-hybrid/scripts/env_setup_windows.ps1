Param(
    [switch]$NoPreCommit = $false
)

Write-Host "=== Quantum Interconnect: Windows Bootstrap ==="

python -V
if (-not $?) { Write-Error "Python not found on PATH"; exit 1 }

# Create venv
if (-not (Test-Path ".venv")) {
    Write-Host "Creating .venv ..."
    python -m venv .venv
}
Write-Host "Activating .venv ..."
# Support PowerShell
& .\.venv\Scripts\Activate.ps1

Write-Host "Upgrading pip ..."
python -m pip install --upgrade pip

Write-Host "Installing requirements ..."
pip install -r requirements.txt

if (-not $NoPreCommit) {
    Write-Host "Installing pre-commit hooks ..."
    pre-commit install
}

Write-Host "Bootstrap complete."
