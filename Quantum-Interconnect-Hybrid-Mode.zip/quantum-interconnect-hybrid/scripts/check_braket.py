from qiskit_braket_provider import AWSBraketProvider

def main():
    try:
        provider = AWSBraketProvider()
        names = [b.name for b in provider.backends()]
        print("AWS Braket backends visible via Qiskit:", names[:10], " ... total:", len(names))
        print("Try: 'Harmony' (IonQ), 'Aria 1' (IonQ Aria), 'SV1' (sim), 'TN1' (sim)")
    except Exception as exc:
        print("Could not access AWS Braket via provider. Is AWS CLI configured? (aws configure)")
        print("Error:", exc)

if __name__ == "__main__":
    main()
