from __future__ import annotations
import numpy as np

def cooperativity(g: float, kappa: float, gamma: float) -> float:
    """Single-photon cooperativity C = 4 g^2 / (kappa * gamma) (units depend on normalization)."""
    return 4.0 * g * g / (kappa * gamma)

def conversion_efficiency_linearized(g: float, kappa_e: float, kappa_o: float, gamma_m: float) -> float:
    """Toy linearized on-resonance conversion efficiency (impedance matched): η ~ 4 g^2 / ((kappa_e + kappa_o) * gamma_m).
    Returns a value in [0, 1] after clamping.
    """
    eta = 4.0 * g * g / ((kappa_e + kappa_o) * gamma_m + 1e-30)
    return max(0.0, min(1.0, float(eta)))
