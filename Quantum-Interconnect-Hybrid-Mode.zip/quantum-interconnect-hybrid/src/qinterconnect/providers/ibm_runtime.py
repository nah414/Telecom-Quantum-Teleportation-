from __future__ import annotations
from typing import Optional
from qiskit import QuantumCircuit
from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as Sampler

def get_service() -> QiskitRuntimeService:
    # Assumes save_account() has been called (scripts/configure_ibm.py)
    return QiskitRuntimeService()

def run_sampler_example(backend_name: Optional[str] = None) -> dict:
    service = get_service()
    if backend_name is None:
        # Prefer a simulator to avoid queue usage by default
        sims = [b for b in service.backends() if getattr(b, "simulator", False)]
        backend = sims[0].name if sims else None
    else:
        backend = backend_name

    qc = QuantumCircuit(2)
    qc.h(0); qc.cx(0,1); qc.measure_all()

    sampler = Sampler(backend=backend) if backend else Sampler()
    job = sampler.run([qc], shots=256)
    res = job.result()[0]
    return {"backend": backend, "pub_result": res.data}
