from __future__ import annotations
from typing import Optional
from qiskit import QuantumCircuit, transpile
from qiskit_braket_provider import AWSBraketProvider

def run_on_braket(backend_name: str = "SV1", shots: int = 256) -> dict:
    provider = AWSBraketProvider()
    backend = provider.get_backend(backend_name)
    qc = QuantumCircuit(2)
    qc.h(0); qc.cx(0,1); qc.measure_all()
    tqc = transpile(qc, backend=backend)
    job = backend.run(tqc, shots=shots)
    result = job.result()
    try:
        counts = result.get_counts()
    except Exception:
        counts = getattr(result, "measurement_counts", None)
    return {"backend": backend_name, "counts": counts}
