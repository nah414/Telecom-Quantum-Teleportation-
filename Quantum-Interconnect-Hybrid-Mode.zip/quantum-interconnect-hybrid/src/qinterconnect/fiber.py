from __future__ import annotations
import numpy as np

def fiber_loss_db(distance_km: float, alpha_db_per_km: float) -> float:
    """Total fiber loss in dB for length and attenuation coefficient."""
    return float(distance_km * alpha_db_per_km)

def power_out_dbm(power_in_dbm: float, loss_db: float) -> float:
    return power_in_dbm - loss_db

def dispersion_broadening(ps_nm_km: float, spectral_width_nm: float, distance_km: float) -> float:
    """Approximate pulse broadening in ps given dispersion parameter D [ps/(nm·km)]."""
    return ps_nm_km * spectral_width_nm * distance_km

def qber_bb84(est_signal_counts: float, dark_counts: float) -> float:
    """Very simple QBER model: half of dark counts counted as errors over total counts."""
    if est_signal_counts <= 0:
        return 0.5
    return 0.5 * dark_counts / (est_signal_counts + dark_counts)

def key_rate_bb84(signal_rate_hz: float, qber: float, sifting_factor: float = 0.5) -> float:
    """Toy asymptotic key rate approximation (ignores finite-size and EC/PA overheads)."""
    from math import log2
    q = max(1e-12, min(0.49, qber))
    return sifting_factor * signal_rate_hz * (1 - 2 * (-q*log2(q) - (1-q)*log2(1-q)))
