from dataclasses import dataclass
import numpy as np

HBAR = 1.054_571_817e-34  # J*s
C = 299_792_458.0         # m/s
K_B = 1.380_649e-23       # J/K

# Fiber attenuation defaults (typical values; change per vendor/installation)
ALPHA_DB_PER_KM_1550 = 0.20   # ~0.2 dB/km @ 1550 nm
ALPHA_DB_PER_KM_1310 = 0.35   # ~0.35 dB/km @ 1310 nm

# Receiver defaults (illustrative)
DETECTOR_EFFICIENCY = 0.6
DARK_COUNT_RATE = 100.0  # cps

@dataclass
class LinkBudget:
    tx_power_dbm: float
    wavelength_nm: float
    tx_losses_db: float = 2.0
    rx_losses_db: float = 2.0
    margin_db: float = 3.0
