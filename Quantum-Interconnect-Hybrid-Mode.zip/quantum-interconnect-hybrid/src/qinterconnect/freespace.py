from __future__ import annotations
import numpy as np

def rayleigh_range(w0_m: float, wavelength_m: float) -> float:
    return np.pi * w0_m**2 / wavelength_m

def beam_radius(w0_m: float, wavelength_m: float, z_m: float) -> float:
    zR = rayleigh_range(w0_m, wavelength_m)
    return w0_m * np.sqrt(1 + (z_m / zR) ** 2)

def geometric_spreading_loss_db(w0_m: float, wavelength_m: float, z_m: float, aperture_radius_m: float) -> float:
    w = beam_radius(w0_m, wavelength_m, z_m)
    capture = 1.0 - np.exp(-(aperture_radius_m**2) / (2 * w**2))
    capture = max(1e-12, min(1.0, capture))
    return -10 * np.log10(capture)

def hv5_cn2(h_m: float, v_ms: float = 21.0, A: float = 1.7e-14) -> float:
    """Hufnagle–Valley 5/7-ish parametric profile for Cn^2 as function of altitude (meters)."""
    return 0.00594 * (v_ms / 27.0) ** 2 * (10 ** (-5 * h_m)) * np.exp(-h_m / 1000.0) +            2.7e-16 * np.exp(-h_m / 1500.0) + A * np.exp(-h_m / 100.0)

def scintillation_index_weak(cn2: float, k: float, z_m: float) -> float:
    """Rytov variance for plane wave (weak turbulence): sigma_R^2 = 1.23 Cn^2 k^{7/6} z^{11/6}."""
    return 1.23 * cn2 * (k ** (7.0/6.0)) * (z_m ** (11.0/6.0))
