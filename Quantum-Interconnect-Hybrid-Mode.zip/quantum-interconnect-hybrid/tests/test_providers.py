import os
import pytest

@pytest.mark.skipif(not os.path.exists(os.path.expanduser('~/.qiskit')), reason="IBM Runtime not configured")
def test_ibm_runtime_placeholder():
    assert True

@pytest.mark.skipif('AWS_ACCESS_KEY_ID' not in os.environ, reason="AWS not configured")
def test_braket_placeholder():
    assert True
