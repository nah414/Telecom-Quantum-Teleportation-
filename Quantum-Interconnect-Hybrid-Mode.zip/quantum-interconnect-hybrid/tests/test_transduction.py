from qinterconnect import transduction

def test_cooperativity_monotonic():
    assert transduction.cooperativity(1.0, 1.0, 1.0) == 4.0
