from qinterconnect import fiber

def test_fiber_loss_db():
    assert fiber.fiber_loss_db(10, 0.2) == 2.0

def test_qber_bb84():
    qber = fiber.qber_bb84(est_signal_counts=1000, dark_counts=10)
    assert 0.0 <= qber <= 0.5
