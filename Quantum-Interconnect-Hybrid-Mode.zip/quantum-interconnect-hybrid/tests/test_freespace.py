from qinterconnect import freespace
import math

def test_rayleigh_range():
    zR = freespace.rayleigh_range(1e-3, 1.55e-6)
    assert zR > 1.0
