# Quantum Interconnect (Hybrid Mode)

End-to-end, **hybrid-mode** starter for modeling and simulating quantum interconnects that span:
- **Telecom fiber** (attenuation, dispersion, BB84-style link budget)
- **Free-space optical** (Gaussian beam propagation, turbulence models, link budget)
- **Superconducting ↔ optical transduction** (electro-/opto-mechanics; efficiency curves)

Hybrid mode = local simulation + optional hardware execution via:
- **IBM Quantum** (Qiskit Runtime)
- **Amazon Braket** (Qiskit-Braket provider; access to IonQ, Rigetti, IQM, plus managed simulators)

> This repository was generated as a clean, opinionated baseline and includes documentation, tests, CI, and pre-commit hooks. It is intentionally small but extensible.

---

## Quick start (Windows / PowerShell)

```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force
./scripts/env_setup_windows.ps1
# (Optional) configure IBM token
python scripts/configure_ibm.py
# (Optional) verify Braket (requires AWS credentials)
python scripts/check_braket.py
```

Open Jupyter and run the notebooks:

```powershell
jupyter notebook
# Open: notebooks/01_Telecom_Fiber_Link.ipynb
```

**GitHub init** (after you create a repo on GitHub):
```bash
git init
git add .
git commit -m "init: quantum interconnect hybrid-mode scaffolding"
git branch -M main
git remote add origin <YOUR_REPO_URL>
git push -u origin main
```

---

## Repo layout

```
quantum-interconnect-hybrid/
├─ notebooks/
│  ├─ 01_Telecom_Fiber_Link.ipynb
│  ├─ 02_Free_Space_Link.ipynb
│  └─ 03_SC_Optical_Transduction.ipynb
├─ src/qinterconnect/
│  ├─ __init__.py
│  ├─ constants.py
│  ├─ fiber.py
│  ├─ freespace.py
│  ├─ transduction.py
│  └─ providers/
│     ├─ ibm_runtime.py
│     └─ braket_provider.py
├─ tests/
│  ├─ test_fiber.py
│  ├─ test_freespace.py
│  ├─ test_transduction.py
│  └─ test_providers.py
├─ scripts/
│  ├─ env_setup_windows.ps1
│  ├─ configure_ibm.py
│  └─ check_braket.py
├─ docs/
│  ├─ index.md
│  └─ REFERENCES.md
├─ .github/workflows/
│  ├─ ci.yml
│  └─ docs.yml
├─ .pre-commit-config.yaml
├─ .gitignore
├─ LICENSE
├─ pyproject.toml
├─ requirements.txt
└─ mkdocs.yml
```

---

## Notes on hardware integration

- **IBM Quantum**: Uses `qiskit-ibm-runtime`. Configure with `scripts/configure_ibm.py` or directly in code using `QiskitRuntimeService.save_account(...)`.
- **Amazon Braket (IonQ, Rigetti, IQM)**: Uses `qiskit-braket-provider`. Requires AWS credentials (`aws configure`). Device names like `Aria 1` (IonQ), `Harmony` (IonQ), `SV1` (simulator) are available via the provider.

---

## References

A compact bibliography lives in `docs/REFERENCES.md` (fiber attenuation, Gaussian beams, turbulence Cn² ranges, DSOC milestones, and transduction reviews).

---

© 2025-11-04 MIT License.
