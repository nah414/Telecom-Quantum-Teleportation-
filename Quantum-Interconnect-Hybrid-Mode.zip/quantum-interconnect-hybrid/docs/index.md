# Quantum Interconnect — Overview

This project models three layers of a quantum interconnect stack:

1. **Telecom fiber link**: attenuation vs. range, dispersion and PMD placeholders, and a simple BB84 link budget.
2. **Free-space link**: Gaussian beam propagation and turbulence via Cn² ranges, with link margin calculations.
3. **Superconducting ↔ optical transduction**: linearized optomechanical model for conversion efficiency.

See **REFERENCES.md** for the verified sources that underpin the formulas and default constants.

## Hardware backends

- IBM Quantum via **Qiskit Runtime** (Sampler/Estimator V2).
- Amazon Braket via **qiskit-braket-provider** (IonQ, Rigetti, IQM, simulators).

> Tip: Use local simulators first, then toggle hardware backends when credentials are configured.
