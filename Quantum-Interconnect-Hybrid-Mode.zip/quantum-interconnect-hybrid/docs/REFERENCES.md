# References

**Fiber attenuation & parameters**
- ITU-T G.652 (standard single-mode fiber). Summary and typical attenuation (~0.2 dB/km at 1550 nm).  
  https://people.ucsc.edu/~warner/fibertype.html
- Vendor overview of G.652 vs. others (context).  
  https://www.fs.com/blog/is-g652-single-mode-fiber-your-right-choice-1356.html

**Gaussian beams**
- Edmund Optics: Gaussian beam propagation tutorial (w(z), z_R, R(z), Gouy phase).  
  https://www.edmundoptics.com/knowledge-center/application-notes/lasers/gaussian-beam-propagation/
- RP Photonics encyclopedia: Gaussian beams and q-parameter.  
  https://www.rp-photonics.com/gaussian_beams.html

**Atmospheric turbulence (Cn²)**
- Typical near-ground ranges (≈10⁻¹³ to 10⁻¹⁷ m⁻²⁄³; daytime ~10⁻¹⁴, night ~10⁻¹⁵).  
  https://auetd.auburn.edu/bitstream/handle/10415/2379/phd_thesis_inkeun_son.pdf?isAllowed=y&sequence=2
- Gamma–gamma fading and Hufnagle–Valley profile context.  
  https://www.cse.lehigh.edu/~jingli/pub/paper/Twireless2006_FSO_gammagamma.pdf
- NASA NTRS turbulence profiling example (methodology).  
  https://ntrs.nasa.gov/api/citations/20170004747/downloads/20170004747.pdf

**Deep Space Optical Communications (DSOC) milestones**
- NASA DSOC mission page (8.3 Mbps downlink at 249 million miles, June 24, 2024).  
  https://www.nasa.gov/mission/deep-space-optical-communications-dsoc/
- JPL news: DSOC exceeded project expectations; record distance downlink in Dec 2024; summary Sept 2025.  
  https://www.jpl.nasa.gov/news/nasas-deep-space-communications-demo-exceeds-project-expectations/

**Transduction (microwave ↔ optical)**
- Lauk et al., *Perspectives on quantum transduction* (review).  
  https://arxiv.org/abs/1910.04821
- Xu et al., *Optomechanical Microwave-to-Optical Photon Transducer* (review, 2024).  
  https://pmc.ncbi.nlm.nih.gov/articles/PMC11052314/
- Nongthombam et al., *Phys. Rev. A* 108, 043501 (2023): SC qubit to optical photon via electro-optomechanics.  
  https://link.aps.org/doi/10.1103/PhysRevA.108.043501
- Arnold et al., *All-optical superconducting qubit readout* (Nature Physics, 2025).  
  https://www.nature.com/articles/s41567-024-02741-4

**QKD (BB84)**
- Bennett & Brassard (1984) classic (arXiv reprint).  
  https://arxiv.org/abs/2003.06557

**Providers**
- Install Qiskit + IBM Runtime.  
  https://quantum.cloud.ibm.com/docs/guides/install-qiskit
- Save credentials & use `QiskitRuntimeService`.  
  https://quantum.cloud.ibm.com/docs/guides/save-credentials
- Qiskit-Braket provider docs & how-tos.  
  https://qiskit-community.github.io/qiskit-braket-provider/
- AWS blog: Using the Qiskit provider for Braket.  
  https://aws.amazon.com/blogs/quantum-computing/introducing-the-qiskit-provider-for-amazon-braket/
